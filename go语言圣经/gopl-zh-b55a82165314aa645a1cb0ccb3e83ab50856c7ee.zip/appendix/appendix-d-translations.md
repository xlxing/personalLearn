## 附录D：其它语言

下表是 [The Go Programming Language](http://www.gopl.io/) 其它语言版本：

语言 | 链接 | 时间 | 译者 | ISBN
---- | ---- | ---- | ---- | ----
中文     | [《Go语言圣经》][gopl-zh] | 2016/2/1 | [chai2010][chai2010], [Xargin][Xargin], [CrazySssst][CrazySssst], [foreversmart][foreversmart] | ?
韩语     | [Acorn Publishing (Korea)](http://www.acornpub.co.kr/) | 2016 | Seung Lee | 9788960778320
俄语     | [Williams Publishing (Russia)](http://www.williamspublishing.com/) | 2016 | ? | 9785845920515
波兰语   | [Helion (Poland)](http://helion.pl/) | 2016 | ? | ?
日语     | [Maruzen Publishing (Japan)](http://www.maruzen.co.jp/corp/en/services/publishing.html) | 2017 | Yoshiki Shibata | 9784621300251
葡萄牙语 | [Novatec Editora (Brazil)](http://novatec.com.br/) |2017 | ? | ?
中文简体 | [Pearson Education Asia](http://www.pearsonapac.com/) |2017 | ? | ?
中文繁体 | [Gotop Information (Taiwan)](http://www.gotop.com.tw/) | 2017 | ? | ?


[gopl-zh]: http://golang-china.github.io/gopl-zh/  "《Go语言圣经》"

[chai2010]: https://github.com/chai2010
[Xargin]: https://github.com/cch123
[CrazySssst]: https://github.com/CrazySssst
[foreversmart]: https://github.com/foreversmart
